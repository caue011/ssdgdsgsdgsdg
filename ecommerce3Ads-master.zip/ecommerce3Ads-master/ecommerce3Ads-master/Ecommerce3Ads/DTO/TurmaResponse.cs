﻿using Ecommerce3Ads.Model;

namespace Ecommerce3Ads.DTO
{
    public class TurmaResponse
    {
        public string Nome { get; set; }
        public Estudante Estudante { get; set; }

        public TurmaResponse(Turma turma)
        {
            Nome = turma.Nome;
            Estudante = turma.Estudante;
        }


    }
}
