﻿using Ecommerce3Ads.Model;
using System.ComponentModel.DataAnnotations;

namespace Ecommerce3Ads.DTO
{
    public class TurmaRequest
    {
        [MinLength(5)]
        public string Nome { get; set; }

        [Required]
        public int EstudanteId { get; set; }

        public Turma toModel()
            => new Turma(Nome, EstudanteId);
    }
}
