﻿using Ecommerce3Ads.Model;
using System.ComponentModel.DataAnnotations;

namespace Ecommerce3Ads.DTO
{
    public class EstudanteRequest
    {
        [MinLength(5)]
        public string Nome { get; set; }

        public Estudante toModel()
            => new Estudante(Nome);
    }
}
