﻿using Ecommerce3Ads.Context;
using Ecommerce3Ads.DTO;
using Ecommerce3Ads.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Ecommerce3Ads.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TurmaController : ControllerBase
    {
        private readonly DataContext _dataContext;

        public TurmaController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<CategoriaController>
        [HttpGet]
        public ActionResult<List<Turma>> Get()
        {
            var turma = _dataContext.Turma.ToList<Turma>();
            return turma;
        }

        // GET api/<CategoriaController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<CategoriaController>
        [HttpPost]
        public ActionResult<Turma> Post([FromBody] TurmaRequest turmaRequest)
        {
            if (ModelState.IsValid)
            {
                var turma = turmaRequest.toModel();
                _dataContext.Turma.Add(turma);
                _dataContext.SaveChanges();
                return turma;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<CategoriaController>/5
        [HttpPut]
        public ActionResult<Turma> Put([FromBody] Turma turma)
        {
            var turmaeENulo = _dataContext.Turma.FirstOrDefault(turma) == null;
            if (turmaeENulo)
                ModelState.AddModelError("TurmaId", "Id da categoria não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Turma.Update(turma);
                _dataContext.SaveChanges();
                return turma;
            }
            return BadRequest(ModelState);

        }

        // DELETE api/<CategoriaController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var turma = _dataContext.Turma.Find(id);
            if (turma == null)
                ModelState.AddModelError("TurmaId", "Id da categoria não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Turma.Remove(turma);
                _dataContext.SaveChanges();
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }
}
