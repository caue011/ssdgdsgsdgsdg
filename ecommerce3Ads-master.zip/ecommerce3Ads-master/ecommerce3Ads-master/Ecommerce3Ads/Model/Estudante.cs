﻿using System.ComponentModel.DataAnnotations;

namespace Ecommerce3Ads.Model
{
    public class Estudante
    {
        [Key]
        public int Id { get; set; }
        public string Nome { get; set; }

        public Estudante(string nome)
        {
            Nome = nome; 
        }
    }
}
