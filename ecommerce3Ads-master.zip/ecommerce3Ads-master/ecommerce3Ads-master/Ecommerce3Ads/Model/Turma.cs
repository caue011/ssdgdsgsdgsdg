﻿using System.ComponentModel.DataAnnotations;

namespace Ecommerce3Ads.Model
{
    public class Turma
    {
        [Key]
        public int Id { get; set; }
        public string Nome { get; set; }
        public int EstudanteId { get; set; }
        public Estudante Estudante { get; set; }

        public Turma(string nome, int estudanteId)
        {
            Nome = nome;
            EstudanteId = estudanteId;
        }
    }
}
